---
name: Bug report
about: Report an Android Agent behavior or connection failure
---

**Versions:** APK, server revision, Android version, assistant surface/model.

**Task and expected outcome:** Use a redacted example and test account.

**Actual outcome and exact tool error code:**

**Steps to reproduce:**

**Evidence:** Sanitized screenshots/logs only. Do not attach pairing tokens,
owner approval keys, OAuth credentials, private messages, or raw screen dumps.

**Was the device unlocked, connected and owner-enabled?**

**Was this a benchmark episode?** Include task ID, seed and run ID if applicable.
