## Change

Explain the user-visible problem and resulting behavior.

## Validation

List relevant tests and actual device/emulator checks. Separate a code test pass
from an autonomous task success or benchmark score.

## Limits

Describe permission, protocol, compatibility or privacy implications if changed.
